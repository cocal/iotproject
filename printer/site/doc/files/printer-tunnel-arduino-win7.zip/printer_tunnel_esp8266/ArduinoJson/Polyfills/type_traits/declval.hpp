// ArduinoJson - https://arduinojson.org
// Copyright © 2014-2023, Benoit BLANCHON
// MIT License

#pragma once

#include "../../Namespace.hpp"

ARDUINOJSON_BEGIN_PRIVATE_NAMESPACE

template <typename T>
T&& declval();

ARDUINOJSON_END_PRIVATE_NAMESPACE

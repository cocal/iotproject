// ArduinoJson - https://arduinojson.org
// Copyright © 2014-2023, Benoit BLANCHON
// MIT License

#pragma once

#include "../Namespace.hpp"

ARDUINOJSON_BEGIN_PRIVATE_NAMESPACE

// The default writer is a simple wrapper for Writers that are not copiable
template <typename TDestination, typename Enable = void>
class Writer {
 public:
  explicit Writer(TDestination& dest) : dest_(&dest) {}

  size_t write(uint8_t c) {
    return dest_->write(c);
  }

  size_t write(const uint8_t* s, size_t n) {
    return dest_->write(s, n);
  }

 private:
  TDestination* dest_;
};

ARDUINOJSON_END_PRIVATE_NAMESPACE

#include "Writers/StaticStringWriter.hpp"

#if ARDUINOJSON_ENABLE_STD_STRING
#include "Writers/StdStringWriter.hpp"
#endif

#if ARDUINOJSON_ENABLE_ARDUINO_STRING
#include "Writers/ArduinoStringWriter.hpp"
#endif

#if ARDUINOJSON_ENABLE_STD_STREAM
#include "Writers/StdStreamWriter.hpp"
#endif

#if ARDUINOJSON_ENABLE_ARDUINO_PRINT
#include "Writers/PrintWriter.hpp"
#endif
